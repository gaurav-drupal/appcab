<?php
/**
 * @file
 * Template for a leaflet map
 */
?>
<div id="<?php print $map_id ?>" style="height: <?php print $height ?>"></div>
