<div class="panel"><h5><?php print t('RideClever user new user registration'); ?></h5>
  <!-----RideClever is a safe and easy way to get picked up by safe licensed professional drivers.--->
</div>
<?php echo $rendered; ?>