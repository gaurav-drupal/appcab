<div class="panel"><h5><?php print t('RideClever user login'); ?></h5>
<!-----RideClever is a safe and easy way to get picked up by safe licensed professional drivers.---><!----<img src="/sites/all/themes/rideclever/114.png" alt="gaurav" /> -->
  <div class="red"><?php print t('Forgot password?'); ?><a href="/user/password"><?php print t('Click here'); ?></a>
  </div>
</div>
<?php echo $rendered; ?>